// dfs 
var main = function(words) {
    //words is an array, the item in it is a string word
    var len = words.length;
    var inDegree[30], outDegree[30],G[30][30],vst[30],f,ok,c[30],cnt,ts;

    var init = function(){
        for(var i = 0; i < 30; i++) {
            inDegree[i] = 0;
            outDegree[i] = 0;
            vst[i] = 0;
            G[i] = [];
            for(var j = 0; j < 30; j++) {
                G[i][j] = 0;
            }
        }
        
        cnt=0;
        for (var i=0;i< len; i++){
            var p = words[i][0]-'a';
            var q = words[i][words[i].length-1]-'a';
            ts=p;   //ts会变成最后一个输入单词的首字母
            if (!c[p]) {cnt++;c[p]=1;}
            if (!c[q]) {cnt++;c[q]=1;}
            G[p][q]=1;
            inDegree[p]++;
            outDegree[q]++;
        }    
    }

    var is_link = function(p){
        for (var j=0; j<30; j++){
            if (G[p][j]&&!vst[j]){
                vst[j]=1;
                f++;
                is_link(j);
            }
        }
    }

    var find_start = function(){
        for (var i=0;i<30;i++)
            if (inDegree[i]-outDegree[i]==1) return i;
        if (i==30) 
            return ts;
    }

    var work = funcion(){
        var t=0,f=0;
        for (var i=0;i<30;i++)        
                if (inDegree[i]!=outDegree[i]){
                    if (abs(inDegree[i]-outDegree[i])==1)t++;
                    else f=1;
                }
        if ((t==0&&f==0)||(t==2)) return 1;
        return 0;
    }

    init();
    ok=1;
    var p=find_start();
    vst[p]=1;
    f=1;
    if (ok)
        is_link(p);
    if (f!=cnt) ok=0;
    if (ok) ok=work();
    return ok;
}


////////////并查集
var main = function(words) {
    var  Find = function(x) { 
        if (x != f[x])  
            return f[x] = Find(f[x]); 
        return x; 
    } 
    
    var f, id, od, g;
    for (int i = 0; i < 30; i++) { 
        f[i] = i; 
        id[i] = 0; 
        od[i] = 0; 
        g[i] = 0;
        for (int j = 0; j < 30; j++) 
            g[i][j] = 0; 
    } 
    
    for (int i = 0; i < words.length; i++) { 
        var a = words[i][0] - 'a', b = words[i][words[i].length - 1] - 'a'; 
        g[a][b]++; 
        od[a]++; 
        id[b]++; 
        f[Find(a)] = Find(b); 
        root = Find(b); 
    } 

    var i, ans = 0, flag = 1, in = 0, on = 0; 
    for (i = 0; i < 30; i++) 
    if (id[i] || od[i]) { 
        if (Find(f[i]) != root) 
            ans++; 
        if (id[i] - od[i] == 1) 
            in++; 
        else if (od[i] - id[i] == 1) 
            on++; 
        else if (abs(id[i] - od[i]) > 1) 
            break; 
    } 

    if (i < 30 || ans > 0 || in > 1 || on > 1) 
       return false
    else
        return true; 
} 
}