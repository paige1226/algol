A[i] = [m, n]

A[i] is a matrix , the total matrix number is N. It means A.length = N

expression is express = " (A[1]A[2](A[3]A[4])A[5]) "

////////
var twoMultiple = function(a1, a2) {
	if(a1[1] !== a2[0]) {
		return -1;
	} else {
		return a1[0]*a1[1]*a2[1];
	}
}

var findAll = function(express, A) {
	var stack = [];

	var result = 0;

	for(var i = 0; i < express.length; i++) {
		if(express[i] == '(') {
			//do nothing
		} else if(express[i] == ')') {
			var a2 = stack.pop();
			var a1 = stack.pop();
			var tmp = twoMultiple(a1, a2);
			if(tmp > 0) {
				result += tmp;
			} else {
				return -1;
			}
			stack.push([a1[0], a2[1]]);
		} else {
			stack.push(A[express[i]]);
		}
	}
	return result;
}

