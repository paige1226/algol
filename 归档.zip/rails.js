//n is the number of rails
//output is 1..n array

var isOk = function(n, output) {
	var stack = [];
	//b scan output array
	//a scan the sequence from 1 to n;
	var a = 1, b = 1;
    var ok = true;
    while (b <= n) {
        if (a == output[b]) {
            a++;
            b++;
        } else if (stack.length > 0 && stack[stack.length - 1] == output[b]) {
            stack.pop();
            b++;
        } else if (a <= n) {
            stack.push(a++);
        } else {
            ok = false;
            break;
        }
    }
    
    return ok;
}