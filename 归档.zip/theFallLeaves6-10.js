//开一个数组，根在数组最中央mid，根的左子树在mid-1， 根的右子树在mid+1

var array = [];
var max = 10000;
input = [8 2 9 -1 -1 6 5 -1 -1 12 -1 -1 3 7 -1 -1 -1];

var findLeaves = function(index) {
	if(input.length > 0) {
		var val = input.shift(); //第一个元素从其中删除，并返回第一个元素的值
		if(val != -1) {
			array[index] += val;
			findLeaves(index - 1);
			findLeaves(index + 1);
		}
	} else {
		return;
	}
}

findLeaves(max/2);
var result = [];
for(var i = 0; i < array.length; i++) {
	if(array[i]) {
		result.push(array[i]);
	}
}
return result;