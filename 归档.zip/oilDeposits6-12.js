var pic = [
	[0 0 0 0 1]
	[0 1 1 0 1]
	[0 1 0 0 1]
	[1 1 1 0 1]
	[1 1 0 0 1]
]

var main = function(pic, x , y) {
	var char = pic[x, y];

	var buf = [];
	var m = pic.length;
	var n = pic[0].length;
	for(var i = 0; i < m; i++) {
		buf[i] = [];
		for(var j = 0; j < n; j++) {
			buf[i][j] = 0;
		}
	}	

	var dfs = function(r, c) {
		if(r < 0 || r >= m || c < 0 || c >= n) 
			return;
		if(buf[r][c] != 0 || pic[r][c] != char) //已经找过了，或者不是给定字符
			return;
		buf[r][c] = 1;
		dfs(r-1, c-1);
		dfs(r, c+1);
		dfs(r+1, c);
		dfs(r+1, c-1);
	}

	dfs(x, y);

	//count 1's number in buf
	var count = 0
	for(var i = 0; i < m; i++) {
		for(var j = 0; j < n; j++) {
			count += buf[i][j];
		}
	}	
}