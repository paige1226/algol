var main = function(width, s1, s2){
	var count = 0;
	var buf = [];
	for(var i = 0; i < width; i++) {
		buf[i] = [];
	}

	// 2  1
	// 3  4
	var parseALen = function(s, width) {
		var index = 0;
		var draw = function(s, r, c, w) {
			var char = s[index];
			index++;
			if(char == 'p') {
				draw(s, index, r, c+w/2, w/2);
				draw(s, index, r, c, w/2);
				draw(s, index, r+w/2, c, w/2);
				draw(s, index, r+w/2, c+w/2, w/2);
			} else if(char == 'f') {
				for(var i = r; i < r+w; i++) {
					for(var j = c; j < c+w; j++) {
						if(buf[i][j] == 0) {
							buf[i][j] = 1;
							count++;
						}
					}
				}
			}
		}
		draw(s1, 0, 0, 0, width);
	}

	parseALen(s1, width);
	parseALen(s2, width);
	return count;
}