inOrderTree = [3,2,1,4,5,7,6];
postOrderTree = [3,1,2,5,6,7,4];

BTree = {
	val: int,
	left: BTree,
	right: BTree
}

var createNode = function(val) {
	var node = new BTree(val);
	node.left = null;
	node.right = null;
	return node;
}

var root = createNode(null);

var createTree = function(inOrderTree, postOrderTree, root) {
	var rootVal = postOrderTree[postOrderTree.length - 1];
	var root.val = rootVal;
	var inOrderTreeL = 0;
	while(inOrderTree[inOrderTreeL] !== rootVal) {
		inOrderTreeL++;
	}
	var leftChildInOrderTree = inOrderTree.slice(0, inOrderTreeL - 1);
	var rightChildInorderTree = inOrderTree.splice(0, 1);

	var leftChildPostOrderTree = postOrderTree.slice(0, inOrderTreeL - 1);
	var rightChildPostOrderTree = postOrderTree.slice(0, rightChildInorderTree.length - 1);

	var leftNode = createNode(null);
	var rightNode = createNode(null);
	root.left = createTree(leftChildInOrderTree, leftChildPostOrderTree, leftNode);
	root.right = createTree(rightChildInorderTree, rightChildPostOrderTree, rightNode);
}

var bestNode = null, bestSum = 1000000;

var dfs(bTree, sum) {
	sum += bTree.val;
	if(!bTree.left && !bTree.right) {
		//leave
		if(sum < bestSum || (sum == bestSum && bTree.val < bestNode.val )) {
			bestNode = bTree;
			bestSum = sum;
		}
	}
	if(bTree.left) {
		dfs(bTree.left, sum);
	}
	if(bTree.right) {
		dfs(bTree.right, sum);
	}
}

var result = dfs(root, 0);

return result;