var main = function(buf) {
	//buf是个二维数组，画了一课树
	var result;
	var n = buf.length;
	var dfs = function(r, c) {
		//递归遍历以buf[r][c]为根的树
		result += "("+ buf[r][c];
		if(r + 1 < n && buf[r+1][c] == '|') { //有子树
			var i = c;
			while(i-1 >=0 && buf[r+2][i-1] == '-')  //找------的左边界
				i--;
			while(buf[r+2][i] == '-' && buf[r+3][i] != '\0') {
				if(!isspace(buf[r+3][i]))  //找到一个子树
					dfs(r+3, i);
				i++;
			}
		}
		result += ')';
	}

	var i = 0;
	while(i < buf[0].length) { //找到根节点位置
		if(buf[0][i] == ' ') 
			i++
	}
	result = "(";
	dfs(0, i);
	result += ")";
	return result;
}