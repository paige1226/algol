var input = [[11, LL], [7, LLL], [8, R], [5], [4, L], [13, RL], [2, LLR], [1, RRR], [4, RR]];

BTree = {
	val: int,
	left: BTree,
	right: BTree
}

var createNode = function(val) {
	var node = new BTree(val);
	node.left = null;
	node.right = null;
	return node;
}

var createTree = function(input) {
	var root = createNode(null);

	var pastNode = root;
	for(var i = 0; i < input.length; i++) {
		var curNodeInput = input[i];
		var val = curNodeInput[0];
		var path = curNodeInput[1];

		if(!path) {
			//root
			root.val = val;
		} else {
			for(var j = 0; j < path.length; j++) {
				var curPath = path[j];
				if(curPath == 'L') {
					if(!pastNode.left) {
						var node = createNode(null);
						pastNode.left = node;
						pastNode = pastNode.left;
					} 
				}else {
					if(!pastNode.right) {
						var node = createNode(null);
						pastNode.right = node;
						pastNode = pastNode.right;
					} 	
				}
			}
			pastNode.val = val;
		}
	}

	//BFS 宽度优先遍历树，利用队列遍历
	var queue = [];
	var result = [];
	queue.push(root);
	while(queue.length > 0) {
		var node = queue.splice(0, 1); // find the first value of the queue;
		result.push(node.val);
		if(node.left)
			queue.push(node.left);
		if(node.right)
			queue.push(node.right); 
	}

	return result;
}