//there are n tasks, the task relationship number is m, the relationship is put in relation[[], [], [], []]

var main = function(n, relations) {
	var topo = [];
	var c = [];
	for(var i = 0; i < n; i++) {
		c[i] = 0;
	}

	//build G, G是二维数组，如果G[r][c] = 1，表示任务r在任务c之前完成。如果为0，表示二者没有相关性
	var G = [];
	for(var i = 0; i < n, i++) {
		G[i] = [];
		for(var j = 0; i < n; j++) {
			G[i][j] = 0;
		}
	}
	for(var i = 0; i < relations.length; i++) {
		var r = relations[i][0];
		var c = relations[i][1];
		G[r][c] = 1;
	} 

	var t = n; 
	var dfs= function(u) {
		c[u]=-1;//c[u]=0表示该点没被访问过，c[u]=-1表示正在访问，c[u]=1表示已经访问过；  
	    for(var i==0; i<n; i++)  
	    {  
	        if(G[u][i])  
	        {  
	            if(c[i]<0)//如果正在访问的点它的后继为-1的话说明该点再次出现了，代表有环，失败退出；  
	                return false;  
	            else if(!c[i]&&!dfs(i))//如果正在访问的点它的后继中某个点在求dfs时，dfs为假，则说明正在访问的点它的后继中某个点再次出现了，则后继中有环，失败退出  
	                return false;  
	        }  
	  
	    }  
	    c[u]=1;  
	    top[--t]=u;//由于是递归调用，所以应当倒着存储；  
	    return true;  
	}

	var isOK = true;
	for(var i=0; i<n; i++)  {
	    if(!c[i]) {  
	        if(!dfs(i))  
	            isOK = false;  
	    }  
	}
        
  	if(isOK) {
  		return topo;
  	}
	
}