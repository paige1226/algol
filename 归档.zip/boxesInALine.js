//input n: the number of the box
// input commands[m]

var result = function(n, commands) {
	

	var left = [];
	var right = [];
	for(var i = 1; i <= n; i++) {
		left[i] = i-1;
		right[i] = (i + 1) % (n + 1);
	}
	left[0] = n;
	right[0] = 1;

	var link = function(l, r) {
		right[l] = r;
		left[r] = l;
	};

	var inv = 0; //remember whether the command is 4.
	var m = commands.length;
	for(var i = 0; i < commands.length; i++){
		if(commands[i][0] == 4) {
			inv = !inv;
		} else {
			x = commands[i][1];
			y = commands[i][2];
			op = commands[i][0];
			if(op == 3 && right[y] == x) swap(x, y);
			if(op != 3 && inv) 
				op = 3 - op;
			if(op == 1 && x == left(y)) continue;
			if(op == 2 && y == right(x)) continue;

			var LX = left[x], RX = right[x], LY = left[y], RY = right[y];
			if(op == 1) {
 				link(LX, RX); link(LY, X); link(X, Y);
			} else if(op == 2) {
				link(LX, RX); link(Y, X); link(X, RY);
			} else if(op == 3) {
				if(right[x] == y) {
					link(LX, Y); link(Y, X); link(X, RY);
				} else {
					link(LX, Y); link(Y, RX); link(LY, X); link(X, RY);
				}
			}
		}	
	}

	var resultOdd = 0;
	var resultEven = 0;
	var b = 0;
	for(var i = 1; i <= n; i++) {
		b = right[b];
		if(i % 2 == 1) {
			// odd box, add the box number
			resultOdd += b;
		} else {
			resultEven += b;
		}
	}

	if(inv &&  n%2 == 0) {
		//偶数个箱子翻转
		return resultEven;
	} else {
		return resultOdd;
	}
}

